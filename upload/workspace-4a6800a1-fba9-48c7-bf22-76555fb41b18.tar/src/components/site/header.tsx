"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import {
  ChevronDown,
  Code2,
  GraduationCap,
  Megaphone,
  Menu,
  Monitor,
  Wrench,
} from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { cn } from "@/lib/utils";
import { Logo } from "./logo";
import { Pill } from "./pill";

const solutionItems = [
  {
    icon: Monitor,
    label: "ICT Equipment & Supply",
    hint: "Computers, laptops & office equipment",
  },
  {
    icon: Code2,
    label: "Software & Digital Solutions",
    hint: "Websites, apps & custom software",
  },
  {
    icon: Megaphone,
    label: "Digital Marketing",
    hint: "Visibility, reach & engagement",
  },
  {
    icon: GraduationCap,
    label: "ICT Training",
    hint: "Practical digital skills for teams",
  },
  {
    icon: Wrench,
    label: "Technical Support",
    hint: "Repairs, maintenance & assistance",
  },
];

const navLinks = [
  { label: "Home", href: "#home" },
  { label: "Products & Supply", href: "#products" },
  { label: "About Us", href: "#about" },
  { label: "Contact", href: "#contact" },
];

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header className="fixed inset-x-0 top-0 z-50 px-3 pt-3 sm:px-5 sm:pt-4">
      <div
        className={cn(
          "mx-auto flex max-w-7xl items-center justify-between gap-4 rounded-full border px-4 py-2.5 transition-all duration-500 sm:px-5",
          scrolled
            ? "border-sand bg-white/90 shadow-card backdrop-blur-xl"
            : "border-transparent bg-white/60 backdrop-blur-md"
        )}
      >
        <Link href="#home" aria-label="Altagracia Technologies — home" className="shrink-0">
          <Logo />
        </Link>

        {/* Desktop nav */}
        <nav aria-label="Main navigation" className="hidden items-center gap-0.5 lg:flex">
          <Link
            href="#home"
            className="rounded-full px-4 py-2 text-sm font-medium text-ink/80 transition-colors hover:bg-cream hover:text-ink"
          >
            Home
          </Link>

          {/* Solutions dropdown */}
          <div
            className="relative"
            onMouseEnter={() => setDropdownOpen(true)}
            onMouseLeave={() => setDropdownOpen(false)}
          >
            <Link
              href="#solutions"
              className={cn(
                "flex items-center gap-1.5 rounded-full px-4 py-2 text-sm font-medium transition-colors hover:bg-cream hover:text-ink",
                dropdownOpen ? "bg-cream text-ink" : "text-ink/80"
              )}
              aria-haspopup="true"
              aria-expanded={dropdownOpen}
              onClick={() => setDropdownOpen(false)}
            >
              Solutions
              <ChevronDown
                className={cn(
                  "size-3.5 transition-transform duration-300",
                  dropdownOpen && "rotate-180"
                )}
              />
            </Link>
            <div
              className={cn(
                "absolute left-1/2 top-full z-40 -translate-x-1/2 pt-3 transition-all duration-300",
                dropdownOpen
                  ? "visible translate-y-0 opacity-100"
                  : "invisible -translate-y-1 opacity-0"
              )}
            >
              <div className="w-[22rem] rounded-3xl border border-sand bg-white p-2 shadow-soft">
                {solutionItems.map((item) => (
                  <Link
                    key={item.label}
                    href="#solutions"
                    onClick={() => setDropdownOpen(false)}
                    className="flex items-start gap-3.5 rounded-2xl px-4 py-3 transition-colors hover:bg-cream"
                  >
                    <span className="mt-0.5 flex size-9 shrink-0 items-center justify-center rounded-full bg-lemon/90 text-ink">
                      <item.icon className="size-4" />
                    </span>
                    <span>
                      <span className="block text-sm font-semibold text-ink">{item.label}</span>
                      <span className="mt-0.5 block text-xs text-stone-warm">{item.hint}</span>
                    </span>
                  </Link>
                ))}
              </div>
            </div>
          </div>

          {navLinks.slice(1).map((link) => (
            <Link
              key={link.label}
              href={link.href}
              className="rounded-full px-4 py-2 text-sm font-medium text-ink/80 transition-colors hover:bg-cream hover:text-ink"
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <Pill href="#contact" variant="ink" className="hidden px-6 py-2.5 sm:inline-flex">
            Request a Quote
          </Pill>

          {/* Mobile menu */}
          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger
              aria-label="Open menu"
              className="flex size-10 items-center justify-center rounded-full border border-sand bg-white text-ink transition-colors hover:bg-cream lg:hidden"
            >
              <Menu className="size-5" />
            </SheetTrigger>
            <SheetContent
              side="top"
              className="rounded-b-3xl border-sand bg-cream px-6 pb-8 pt-5"
            >
              <SheetHeader className="p-0">
                <SheetTitle className="sr-only">Navigation menu</SheetTitle>
                <SheetDescription className="sr-only">
                  Altagracia Technologies site navigation links
                </SheetDescription>
              </SheetHeader>
              <nav aria-label="Mobile navigation" className="mt-2 flex flex-col gap-1">
                <Link
                  href="#home"
                  onClick={() => setOpen(false)}
                  className="rounded-2xl px-4 py-3 font-display text-2xl font-medium text-ink transition-colors hover:bg-white"
                >
                  Home
                </Link>
                <Link
                  href="#solutions"
                  onClick={() => setOpen(false)}
                  className="rounded-2xl px-4 py-3 font-display text-2xl font-medium text-ink transition-colors hover:bg-white"
                >
                  Solutions
                </Link>
                {navLinks.slice(1, 3).map((link) => (
                  <Link
                    key={link.label}
                    href={link.href}
                    onClick={() => setOpen(false)}
                    className="rounded-2xl px-4 py-3 font-display text-2xl font-medium text-ink transition-colors hover:bg-white"
                  >
                    {link.label}
                  </Link>
                ))}
                <Link
                  href="#contact"
                  onClick={() => setOpen(false)}
                  className="rounded-2xl px-4 py-3 font-display text-2xl font-medium text-ink transition-colors hover:bg-white"
                >
                  Contact
                </Link>
                <Pill href="#contact" variant="ink" className="mt-4 w-full" onClick={() => setOpen(false)}>
                  Request a Quote
                </Pill>
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}

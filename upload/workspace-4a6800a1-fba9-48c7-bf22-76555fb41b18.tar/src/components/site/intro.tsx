import { Asterisk } from "lucide-react";
import { Eyebrow } from "./section-heading";
import { Pill } from "./pill";
import { Reveal } from "./reveal";

export function Intro() {
  return (
    <section id="about" className="bg-cream pb-24 pt-24 lg:pb-32 lg:pt-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid gap-12 lg:grid-cols-12 lg:gap-10">
          <div className="lg:col-span-7">
            <Reveal>
              <Eyebrow>Who We Are</Eyebrow>
            </Reveal>
            <Reveal delay={0.08}>
              <h2 className="font-display mt-5 text-balance text-4xl leading-[1.06] font-medium tracking-tight text-ink sm:text-5xl lg:text-[3.4rem]">
                Your business deserves technology that{" "}
                <em className="font-light italic">works.</em>
              </h2>
            </Reveal>
          </div>
          <div className="lg:col-span-5 lg:pt-16">
            <Reveal delay={0.14}>
              <p className="text-base leading-relaxed text-stone-warm sm:text-lg">
                Technology plays an important role in how businesses operate,
                communicate and grow. Having the right technology partner can
                make all the difference.
              </p>
            </Reveal>
          </div>
        </div>

        <div className="mt-14 grid gap-10 lg:grid-cols-12">
          <div className="lg:col-span-7">
            <Reveal>
              <p className="text-base leading-relaxed text-stone-warm sm:text-lg">
                At <strong className="font-semibold text-ink">Altagracia Technologies</strong>, we
                bring together ICT products, digital services and practical
                technology solutions to help organizations meet their everyday
                and long-term needs.
              </p>
              <p className="mt-5 text-base leading-relaxed text-stone-warm sm:text-lg">
                Whether you&rsquo;re equipping a new office, improving your digital
                presence, developing a software solution or building your
                team&rsquo;s ICT skills, we work to make the process clear and
                straightforward.
              </p>
            </Reveal>
            <Reveal delay={0.1}>
              <div className="mt-9">
                <Pill href="#contact" variant="ink">
                  Get to Know Us
                </Pill>
              </div>
            </Reveal>
          </div>

          <div className="lg:col-span-5">
            <Reveal delay={0.16}>
              <blockquote className="relative rounded-[2rem] border border-sand bg-white p-8 shadow-card sm:p-10">
                <Asterisk
                  className="animate-spin-slow absolute right-8 top-8 size-8 text-lemon"
                  aria-hidden="true"
                />
                <p className="font-display text-2xl leading-snug text-ink sm:text-[1.7rem]">
                  &ldquo;We believe technology should make work easier,{" "}
                  <em className="italic">not more complicated.</em>&rdquo;
                </p>
                <footer className="mt-6 flex items-center gap-3">
                  <span className="h-px w-10 bg-ink/20" aria-hidden="true" />
                  <span className="text-xs font-bold uppercase tracking-[0.2em] text-stone-warm">
                    The Altagracia Belief
                  </span>
                </footer>
              </blockquote>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}

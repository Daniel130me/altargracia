import Image from "next/image";
import { ArrowDown, Asterisk } from "lucide-react";
import { Pill } from "./pill";
import { Reveal } from "./reveal";

const railWords = ["Corporate ICT", "Digital Services", "Technology Supply"];

export function Hero() {
  return (
    <section id="home" className="relative overflow-hidden bg-cream">
      {/* decorative shapes */}
      <div
        aria-hidden="true"
        className="absolute -top-24 right-[8%] size-56 rounded-full bg-lemon/80 blur-[2px] sm:size-72"
      />
      <div
        aria-hidden="true"
        className="absolute bottom-16 left-[38%] hidden size-24 rounded-full border-[10px] border-ink/5 lg:block"
      />
      <Asterisk
        aria-hidden="true"
        className="animate-spin-slow absolute left-[45%] top-28 hidden size-10 text-ink/15 lg:block"
      />

      <div className="relative mx-auto max-w-7xl px-4 pb-16 pt-32 sm:px-6 sm:pt-36 lg:px-8 lg:pb-24 lg:pt-44">
        <div className="grid items-start gap-12 lg:grid-cols-12 lg:gap-8">
          {/* left rail */}
          <div className="hidden lg:col-span-2 lg:block">
            <ul className="space-y-2.5">
              {railWords.map((word) => (
                <li
                  key={word}
                  className="font-display text-lg leading-snug text-ink/70"
                >
                  {word}
                </li>
              ))}
            </ul>
            <ArrowDown className="mt-10 size-6 text-ink/30" aria-hidden="true" />
          </div>

          {/* headline + copy + CTAs */}
          <div className="lg:col-span-6">
            <Reveal>
              <p className="text-[11px] font-bold uppercase tracking-[0.22em] text-ink">
                <span className="mr-2.5 inline-block size-1.5 rotate-45 bg-lemon ring-1 ring-ink/20" />
                Corporate ICT Solutions · Digital Services · Technology Supply
              </p>
            </Reveal>

            <Reveal delay={0.08}>
              <h1 className="font-display mt-7 text-balance text-[clamp(2.9rem,6.4vw,5.2rem)] leading-[1.0] font-medium tracking-tight text-ink">
                Technology solutions that{" "}
                <em className="font-light italic">move business</em> forward.
              </h1>
            </Reveal>

            <Reveal delay={0.16}>
              <p className="mt-8 max-w-xl text-base leading-relaxed text-stone-warm sm:text-lg">
                We help businesses and organizations meet their technology needs
                through ICT solutions, equipment supply, digital services and
                professional training.
              </p>
              <p className="mt-4 max-w-xl text-base leading-relaxed text-stone-warm sm:text-lg">
                From your first enquiry to project delivery, our focus is on
                understanding what you need and finding the right solution.
              </p>
            </Reveal>

            <Reveal delay={0.24}>
              <div className="mt-10 flex flex-wrap items-center gap-3.5">
                <Pill href="#solutions" variant="lemon">
                  Explore Our Solutions
                </Pill>
                <Pill href="#contact" variant="outline">
                  Discuss Your Requirements
                </Pill>
              </div>
            </Reveal>
          </div>

          {/* image */}
          <div className="relative lg:col-span-4">
            <Reveal delay={0.15} y={40}>
              <div className="relative overflow-hidden rounded-[2rem] rounded-tl-[6rem] rounded-br-[6rem] shadow-soft">
                <Image
                  src="/images/hero-team.jpg"
                  alt="Business team collaborating around a computer in a modern office"
                  width={1184}
                  height={810}
                  priority
                  className="h-[22rem] w-full object-cover sm:h-[26rem] lg:h-[30rem]"
                />
              </div>
            </Reveal>
          </div>
        </div>

        {/* supporting card */}
        <Reveal delay={0.3}>
          <div className="mt-12 inline-flex max-w-sm items-center gap-5 rounded-[1.75rem] border border-sand bg-white p-6 shadow-card lg:ml-2">
            <Asterisk className="size-8 shrink-0 text-ink" aria-hidden="true" />
            <div>
              <p className="font-display text-lg leading-snug text-ink">
                Technology for businesses. Solutions for progress.
              </p>
              <span className="mt-2 block h-px w-16 bg-ink/20" aria-hidden="true" />
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
